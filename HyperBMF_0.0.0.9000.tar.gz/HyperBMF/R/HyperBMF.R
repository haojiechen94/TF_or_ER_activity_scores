#' @title Jointly Inferring TR_activity and Regulatory Network in ATAC/ChIP-seq Data
#'
#' @description
#' This function is used for inferring TR_activity and regulatory network in ATAC/ChIP-seq data
#' from a group of samples (n>=3). Inputs are hypervairble regions identified by applying
#' function Hypervariable_analysis on the ATAC/ChIP-seq profiles.
#'
#' @param HyperChIP_res               Hypervariable analysis results from function Hypervariable_analysis.
#'
#' @param genes_annotated_with_peaks  Genes are linked with peaks based on genomic positions, these genes are used for filtering unexpressed TFs
#'
#' @param fdr_cutoff                  Adjusted p value used for identifing significant HVRs (Default: 0.1).
#'
#' @return A list of TR activities and regulatory networks for each TR.
#'
#' @export
#'
#' @author Haojie Chen
#'
#' @examples
#' #Hyper_ChIP_res from function Hypervariable_analysis. Details see "?Hypervariable_analysis".
#'
#' genes_annotated_with_peaks<-linking_peaks_to_genes('./proximal_peaks_to_genes_links.txt')
#' HyperBMF_res<-jointly_inferring_TR_activity_and_regulatory_network(
#'   HyperChIP_res,
#'   genes_annotated_with_peaks,
#'   fdr_cutoff = 0.01)
#'
jointly_inferring_TR_activity_and_regulatory_network<-function(HyperChIP_res,genes_annotated_with_peaks,fdr_cutoff=0.1){
  proximal_result<-HyperChIP_res$proximal
  distal_result<-HyperChIP_res$distal

  num_of_samples<-0
  for(i in colnames(proximal_result)){
    if(grepl('.read_cnt',i)){
      num_of_samples<-num_of_samples+1
    }
  }

  HVRs<-rbind(proximal_result[proximal_result$fdr<fdr_cutoff,],
              distal_result[distal_result$fdr<fdr_cutoff,])

  opts <- list()
  opts[["matrixtype"]]<-'PWM'

  PFMatrixList<-getMatrixSet(JASPAR2018,opts)


  HVRs_coordinates<-GRanges(seqnames=c(as.character(HVRs$chrom)),
                            ranges=IRanges(start=c(HVRs$start),
                                           end=c(HVRs$end)))

  motif_pos<-matchMotifs(PFMatrixList,
                         HVRs_coordinates,
                         genome=BSgenome.Hsapiens.UCSC.hg19,
                         out='matches')

  match_pos<-motifMatches(motif_pos)
  match_pos<-as.matrix(match_pos)
  names<-list()
  for(i in c(1:length(PFMatrixList))){
    names<-append(names,name(PFMatrixList[[i]]))
  }

  colnames(match_pos)<-as.character(names)

  match_pos<-match_pos[,toupper(colnames(match_pos)) %in% genes_annotated_with_peaks]

  chipseq_weight <- matrix(1, nrow = dim(match_pos)[1], ncol = dim(match_pos)[2])
  for(i in 1:length(colnames(match_pos))){
    chipseq_weight[,i] <- ifelse(match_pos[,i], 1, 0)
  }
  Mask_matrix<-chipseq_weight

  data<-HVRs[,colnames(HVRs)[c(4:(4+num_of_samples-1))]]

  TF_activity_model<-"
  data {
      int<lower=0> N; //Number of samples
      int<lower=0> M; //Number of HVRs
      int<lower=0> TR; //Number of TRs
      matrix[N, M] X; //Input matrix
      matrix[M, TR] P; //Prior matrix
  }
  parameters {
      matrix[M, TR] W; //Weight matrix
      matrix<lower=0, upper=1>[N, TR] A; //TR activity matrix
      real<lower=0> tau; //Noise term
      vector<lower=0>[TR] alpha; //ARD prior
  }
  transformed parameters {
      matrix<lower=0>[M, TR] t_alpha;
      real<lower=0> t_tau;
      for(wr in 1:M){
          for(wc in 1:TR){
              t_alpha[wr, wc] = P[wr, wc] == 1 ? inv(sqrt(alpha[wc])) : 0.01;
          }
      }
      t_tau = inv(sqrt(tau));
  }
  model {
      tau ~ gamma(1,1);
      to_vector(A) ~ beta(0.5,0.5);
      alpha ~ gamma(1e-3,1e-3);
      for(r in 1:M){
          for(c in 1:TR){
              W[r,c] ~ normal(0, t_alpha[r, c]);
          }
      }
      to_vector(X) ~ normal(to_vector(A*W'), t_tau);
  }
  "

  X <- t(as.matrix(data))
  N <- dim(X)[1]
  M <- dim(X)[2]
  TR <- dim(match_pos)[2]
  data_to_model <- list(N = N, M = M, TR = TR, X = X, P = Mask_matrix)

  TF_activity_model_stan <- stan_model(model_code = TF_activity_model)

  fit.vb <- vb(TF_activity_model_stan,
               data = data_to_model,
               algorithm = "meanfield",
               iter = 8000,
               output_samples = 300,
               tol_rel_obj = 0.005)

  TR_activity <- apply(extract(fit.vb,"A")[[1]], c(2,3), mean)
  TR_activity<-t(TR_activity)
  colnames(TR_activity)<-colnames(data)
  rownames(TR_activity)<-colnames(match_pos)

  weights <- apply(extract(fit.vb,"W")[[1]], c(2,3), mean)
  colnames(weights)<-colnames(match_pos)
  return(list('TR_activity'=TR_activity,'weights'=weights))
}



