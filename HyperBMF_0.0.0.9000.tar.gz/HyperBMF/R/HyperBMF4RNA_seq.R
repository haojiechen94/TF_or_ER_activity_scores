#' Title
#'
#' @return
#' @export
#'
#' @examples
HyperBMF4RNA_seq<-function(){

}
