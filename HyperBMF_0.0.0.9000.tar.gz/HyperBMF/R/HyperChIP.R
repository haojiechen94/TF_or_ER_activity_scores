#' @title Hypervariable Analysis Using HyperChIP
#'
#' @description
#' This function is used for applying hypervriable analysis on ATAC/ChIP-seq data from a group of samples (n>=3).
#'
#' @param input_proximal,input_distal       Two input data files, including proximal regions and distal regions. Within each input file,
#'                                          the first three columns capture the genomic position of each peak, while the remaining
#'                                          columns contain a counts matrix and an occupancy matrix. We provide a webtool Epigenetic
#'                                          Analysis Platform (EAP[https://www.biosino.org/epigenetics/#]) to prepare these input data or
#'                                          tutorial in Github [https://github.com/haojiechen94/EAP].
#'
#' @param metadata                          This file contained information that described the samples from the input file. For instance,
#'                                          it included details like the tissue type of each sample.
#'
#' @param categorical_variable              One of columns in Metadata, assign colors to samples based on this categorical
#'                                          variable in the PCA space.
#'
#' @param top_number_of_PCs                 Top number of principal components used for TSNE dimesion reduction (Default: 2).
#'
#' @param perplexity                        This parameter control how many nearest neighbours are taken into account when constructing
#'                                          the embedding in the low-dimensional space (Default: floor((num_of_samples-1)/3)).
#'
#' @param filtered_chromosomes              Remove these chromosomes before analysis (Default: c(chrX,chrY,chrM)).
#'
#' @param fdr_cutoff                        Adjusted p value used for identifing significant HVRs (Default: 0.1).
#'
#' @return A list of hypervariale analysis results of proximal regions and distal regions
#'
#' @author Haojie Chen
#'
#' @examples
#' #Data for this example are available in https://github.com/haojiechen94/TF_or_ER_activity_scores/tree/master/data
#' Hyper_ChIP_res<-Hypervariable_analysis(
#' './proximal_peak_regions_2000bp.txt',
#' './distal_peak_regions_2000bp.txt',
#' './GAC_cellines_H3K27ac_ChIP_seq_metadata.csv',
#' 'tissue_type',
#' top_number_of_PCs = 2,
#' perplexity = 0,
#' filtered_chromosomes = c("chrX", "chrY", "chrM"),
#' fdr_cutoff = 0.1
#' )
#' @export
Hypervariable_analysis<-function(input_proximal,
                                 input_distal,
                                 metadata,
                                 categorical_variable,
                                 top_number_of_PCs=2,
                                 perplexity=0,
                                 filtered_chromosomes=c('chrX','chrY','chrM'),
                                 fdr_cutoff=0.1){
  method<-'loc'
  proixmal_raw_reads_count<-read.table(input_proximal,header=T,sep='\t')
  proixmal_raw_reads_count<-proixmal_raw_reads_count[!c(proixmal_raw_reads_count$chrom %in% filtered_chromosomes),]
  distal_raw_reads_count<-read.table(input_distal,header=T,sep='\t')
  distal_raw_reads_count<-distal_raw_reads_count[!c(distal_raw_reads_count$chrom %in% filtered_chromosomes),]
  num_of_samples<-0
  for(i in colnames(proixmal_raw_reads_count)){
    if(grepl('.read_cnt',i)){
      num_of_samples<-num_of_samples+1
    }
  }
  if(perplexity==0){
    perplexity<-floor((num_of_samples-1)/3)
  }

  reads_count<-colnames(proixmal_raw_reads_count)[c(4:(4+num_of_samples-1))]
  occupancy<-colnames(proixmal_raw_reads_count)[c((4+num_of_samples):(4+num_of_samples+num_of_samples-1))]

  proixmal_normalized_data<-MAnorm2::normalize(proixmal_raw_reads_count,
                                               reads_count,occupancy,offset=0.5,baseline='pseudo-reference')
  proixmal_normalized_data<-proixmal_normalized_data[rowMeans(proixmal_normalized_data[reads_count])>0.5,]
  proixmal_biocond<-bioCond(proixmal_normalized_data[reads_count],
                            proixmal_normalized_data[occupancy],name='Proximal')

  distal_normalized_data<-MAnorm2::normalize(distal_raw_reads_count,
                                             reads_count,occupancy,offset=0.5,baseline='pseudo-reference')
  distal_normalized_data<-distal_normalized_data[rowMeans(distal_normalized_data[reads_count])>0.5,]
  distal_biocond<-bioCond(distal_normalized_data[reads_count],
                          distal_normalized_data[occupancy],name='Distal')

  proximal_conds_list<-list(proixmal_biocond)
  proximal_MVC_fitting<-fitMeanVarCurve(proximal_conds_list,method=method,occupy.only=F,args.lp=list(nn=1.0))
  proixmal_biocond<-estParamHyperChIP(proximal_MVC_fitting[[1]])
  proixmal_varTest<-varTestBioCond(proixmal_biocond)
  proximal_p_values<-single.end.pvalue(proixmal_varTest)
  p_value<-proximal_p_values
  proximal_fdrs<-p.adjust(proximal_p_values,method='fdr')
  fdr<-proximal_fdrs
  proximal_result<-cbind(proixmal_normalized_data[c('chrom','start','end')],
                         proixmal_normalized_data[reads_count],
                         proixmal_normalized_data[occupancy],
                         proixmal_varTest[,c('observed.mean','observed.var','prior.var','fold.change')],
                         p_value,fdr)
  flag<-proximal_result$fdr<fdr_cutoff
  plot_MVC_and_HVRs(proximal_MVC_fitting,outdir,'Proximal',flag)

  distal_conds_list<-list(distal_biocond)
  distal_MVC_fitting<-fitMeanVarCurve(distal_conds_list,method=method,occupy.only=F,args.lp=list(nn=1.0))
  distal_biocond<-estParamHyperChIP(distal_MVC_fitting[[1]])
  distal_varTest<-varTestBioCond(distal_biocond)
  distal_p_values<-single.end.pvalue(distal_varTest)
  p_value<-distal_p_values
  distal_fdrs<-p.adjust(distal_p_values,method='fdr')
  fdr<-distal_fdrs
  distal_result<-cbind(distal_normalized_data[c('chrom','start','end')],
                       distal_normalized_data[reads_count],
                       distal_normalized_data[occupancy],
                       distal_varTest[,c('observed.mean','observed.var','prior.var','fold.change')],
                       p_value,fdr)
  flag<-distal_result$fdr<fdr_cutoff
  plot_MVC_and_HVRs(distal_MVC_fitting,outdir,'Distal',flag)

  proximal_zscore_matrix<-scale(t(proximal_result[proximal_result$fdr<fdr_cutoff,reads_count]))
  distal_zscore_matrix<-scale(t(distal_result[distal_result$fdr<fdr_cutoff,reads_count]))
  print('#proximal HVRs')
  print(sum(proximal_result$fdr<fdr_cutoff))
  print('#distal HVRs')
  print(sum(distal_result$fdr<fdr_cutoff))
  zscore_matrix<-cbind(proximal_zscore_matrix,distal_zscore_matrix)
  zscore_matrix<-round(zscore_matrix,5)

  meta_data<-read.table(metadata,sep=',',header=T)
  color_by<-meta_data[[categorical_variable]]
  pcs<-PCA_analysis(zscore_matrix,color_by,outdir)
  tsne<-TSNE_visualization(zscore_matrix,top_number_of_PCs,perplexity,color_by,outdir)
  return(list('proximal'=proximal_result,'distal'=distal_result,
              'PCA'=pcs,'TSNE'=tsne,'metadata'=meta_data))

}
