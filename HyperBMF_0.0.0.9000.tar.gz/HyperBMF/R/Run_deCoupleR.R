#' Estimate TR Activity in RNA-seq Data using deCoupleR
#'
#' @description
#' This function is used for estimating TR activity in a group of RNA-seq samples. It is a wrapper for deCoupleR.
#'
#'
#' @param normalized.count Gene expression matrix
#'
#' @param net              Regulatory network in Package dorothea. Run "library(decoupleR) net<-get_collectri(organism='human',split_complexes=FALSE)" to
#'                         get the data.
#'
#' @param times            The times of permutation to do.
#'
#' @param minsize          The minimum number of targets for each TR.
#'
#' @param n_tfs            The number of top-ranked TRs to return, TRs are ordered by
#'
#' @return A dataframe of TR activities across all samples.
#'
#' @export
#'
#' @author Haojie Chen
#'
#' @examples
#' library(decoupleR)
#' net<-get_collectri(organism='human',split_complexes=FALSE)
#' TF_activities_deCoupleR<-Run_deCoupleR(gene_expression_matrix,net,
#'                                        times=100,
#'                                        minsize=5,
#'                                        n_tfs=NULL)
#'
Run_deCoupleR<-function(normalized.count,net,times=100,minsize=5,n_tfs=NULL){
  subset.net<-net[net$source %in% rownames(normalized.count),]
  if(is.null(n_tfs)){
    n_tfs<-length(unique(subset.net$source))
  }

  # Run wmean
  sample_acts<-run_wmean(mat=normalized.count,
                         net=subset.net,
                         .source='source',
                         .target='target',
                         .mor='mor',
                         times=times,
                         minsize=minsize)

  # Transform to wide matrix
  sample_acts_mat <- sample_acts %>%
    filter(statistic == 'norm_wmean') %>%
    pivot_wider(id_cols = 'condition',
                names_from = 'source',
                values_from = 'score') %>%
    column_to_rownames('condition') %>%
    as.matrix()

  # Get top tfs with more variable means across clusters
  tfs <- sample_acts %>%
    group_by(source) %>%
    summarise(std = sd(score)) %>%
    arrange(-abs(std)) %>%
    head(n_tfs) %>%
    pull(source)
  sample_acts_mat <- sample_acts_mat[,tfs]

  # Scale per sample
  sample_acts_mat <- scale(sample_acts_mat)

  return(sample_acts_mat)
}
