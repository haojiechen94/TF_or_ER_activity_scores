#' @title Linking ATAC/ChIP-seq Peaks to Genes
#'
#' @description
#' This function is used for linking ATAC/ChIP-seq peaks to genes and filtering
#' unexpressed TFs.
#'
#' @param peaks_annotation_file Peaks annotation file, each row contains peak genomic position and overlapping genes,
#'                              proximal genes and nearest genes linked to this peak.
#'                              +-----+-----+---+-----------------+--------------+-------------+
#'                              |chrom|start|end|overlapping_genes|proximal_genes|nearest_genes|
#'                              +-----+-----+---+-----------------+--------------+-------------+
#'                              |chr1	| 205 |220|      CDK18	    |    CDK18	   |    CDK18    |
#'                              +-----+-----+---+-----------------+--------------+-------------+
#'
#' @return A vector of genes annotated with peaks
#'
#' @export
#'
#' @examples
linking_peaks_to_genes<-function(peaks_annotation_file){
  genes_annotated_with_peaks<-c()
  for(i in peaks_to_genes_links$overlapping_genes){
    for(j in strsplit(i,',')){
      genes_annotated_with_peaks<-c(genes_annotated_with_peaks,j)
    }
  }
  for(i in peaks_to_genes_links$proximal_genes){
    for(j in strsplit(i,',')){
      genes_annotated_with_peaks<-c(genes_annotated_with_peaks,j)
    }
  }
  genes_annotated_with_peaks<-unique(genes_annotated_with_peaks)
  return(genes_annotated_with_peaks)
}
