#calculate single end p-value
single.end.pvalue<-function(biocond){
  df<-attr(biocond,"df")
  p.value<-pf(biocond$fold.change,df[1],df[2],lower.tail=F)
  return(p.value)
}

#plot MVC and highlight HVRs
plot_MVC_and_HVRs<-function(MVC_fitting,outdir,type,flag){
  smoothScatter(MVC_fitting[[1]]$sample.mean,log10(MVC_fitting[[1]]$sample.var),
                xlab=expression(paste('Observed mean ',log[2],'(read count)')),
                ylab=expression(paste(Log[10],'(observed variance)')),
                main=gettextf('%s regions',type),cex.main=2,cex.lab=1.2,cex.axis=1.2)
  xs<-seq(min(MVC_fitting[[1]]$sample.mean),max(MVC_fitting[[1]]$sample.mean),0.1)
  lines(xs,log10(MVC_fitting[[1]]$fit.info$predict(xs)),lwd=3,col='red')
  points(MVC_fitting[[1]]$sample.mean[flag],log10(MVC_fitting[[1]]$sample.var)[flag],col='red')
  legend("bottomleft",gettextf('Significant HVRs (n=%s)',sum(flag)),
         inset=0.0025,
         pch=c(21),
         cex=1.5,
         col='red',
         xpd=T)
}


#get TF motif PWMs from Jaspar database
getJasparMotifs <- function(species = "Homo sapiens",
                            collection = "CORE", ...) {
  opts <- list()
  opts["species"] <- species
  opts["collection"] <- collection
  opts <- c(opts, list(...))
  out <- TFBSTools::getMatrixSet(JASPAR2018::JASPAR2018, opts)
  if (!isTRUE(all.equal(TFBSTools::name(out), names(out))))
    names(out) <- paste(names(out), TFBSTools::name(out), sep = "_")
  return(out)
}


#PCA analysis
PCA_analysis<-function(zscore_matrix,color_by,outdir){
  color_by<-as.character(color_by)
  unique_labels<-unique(color_by)
  color_list<-hue_pal()(length(unique_labels))
  names<-c()
  values<-c()
  for(i in c(1:length(unique_labels))){
    names<-c(names,unique_labels[i])
    values<-c(values,color_list[[i]])
  }
  color_map<-setNames(values,names)
  colors<-c()
  for(i in color_by){
    colors<-c(colors,color_map[[i]])
  }

  pcs<-pca(zscore_matrix,nPcs=2)

  plot(round(scores(pcs)[,'PC1'],3),
       round(scores(pcs)[,'PC2'],3),
       bg=colors,
       col='black',pch=21,
       xlab=gettextf('PC 1 (%.1f%%)',pcs@R2[1]*100),
       ylab=gettextf('PC 2 (%.1f%%)',pcs@R2[2]*100),
       cex.lab=1.2,cex=2,cex.axis=1.2,cex.main=1.8)
  legend('topright',names,
         inset=c(-0.42,0),
         pch=c(19),
         cex=1.3,
         col=values,ncol=1,
         xpd=T)
  return(pcs)
}

#TSNE visualization
TSNE_visualization<-function(zscore_matrix,top_number_of_PCs,perplexity,color_by,outdir){

  color_by<-as.character(color_by)
  unique_labels<-unique(color_by)
  color_list<-hue_pal()(length(unique_labels))
  names<-c()
  values<-c()
  for(i in c(1:length(unique_labels))){
    names<-c(names,unique_labels[i])
    values<-c(values,color_list[[i]])
  }
  color_map<-setNames(values,names)
  colors<-c()
  for(i in color_by){
    colors<-c(colors,color_map[[i]])
  }

  set.seed(1234)
  tsne_out<-Rtsne(zscore_matrix,dims=2,perplexity=perplexity,initial_dims=top_number_of_PCs)

  plot(tsne_out$Y[,1],tsne_out$Y[,2],
       col='black',pch=21,bg=colors,
       cex=1.5,cex.main=1.5,
       xlab='t-SNE dimension 1',ylab='t-SNE dimension 2',cex.lab=1.2,cex.axis=1.2)

  legend('topright',names,
         inset=c(-0.42,0),
         pch=c(19),
         cex=1.3,
         col=values,ncol=1,
         xpd=T)
  return(tsne_out)
}


#color map for TR activity visualization
color_map<-function(xs,n_bins=10,cmap='RdYlBu'){
  vmin<-min(xs)
  vmax<-max(xs)
  values<-seq(vmin,vmax,(vmax-vmin)/n_bins)
  palette<-rev(brewer.pal(n_bins,cmap))
  color_map_df<-list()
  color_map_df[['color']]<-palette
  color_map_df[['value1']]<-values[1:n_bins]
  color_map_df[['value2']]<-values[2:(n_bins+1)]
  color_map_df<-as.data.frame(color_map_df)
  return(as.character(lapply(xs,function(x){if(x>=vmax){return(palette[length(palette)])}else if(x<=vmin){
    return(palette[1])}else{return(as.character(color_map_df$color[c(color_map_df$value1<=x)&c(color_map_df$value2>x)]))}})))
}


#TR activity visualization in PCA space
PCA_visualization<-function(pcs,color_by){
  color_by<-as.character(color_by)
  unique_labels<-unique(color_by)
  color_list<-hue_pal()(length(unique_labels))
  names<-c()
  values<-c()
  for(i in c(1:length(unique_labels))){
    names<-c(names,unique_labels[i])
    values<-c(values,color_list[[i]])
  }
  color_map<-setNames(values,names)
  colors<-c()
  for(i in color_by){
    colors<-c(colors,color_map[[i]])
  }


  plot(scores(pcs)[,'PC1'],scores(pcs)[,'PC2'],
       bg=colors,
       col='black',pch=21,
       xlab=gettextf('PC 1 (%.1f%%)',pcs@R2[1]*100),
       ylab=gettextf('PC 2 (%.1f%%)',pcs@R2[2]*100),
       cex.lab=1.2,cex=2,cex.axis=1.2,cex.main=1.8)
  legend('topright',names,
         inset=c(-0.42,0),
         pch=c(19),
         cex=1.3,
         col=values,ncol=1,
         xpd=T)
}

#get those genes linked to peaks, use these genes to filtering unexpressed TFs
linking_peaks_to_genes<-function(peaks_annotation_file){
  genes_annotated_with_peaks<-c()
  for(i in peaks_to_genes_links$overlapping_genes){
    for(j in strsplit(i,',')){
      genes_annotated_with_peaks<-c(genes_annotated_with_peaks,j)
    }
  }
  for(i in peaks_to_genes_links$proximal_genes){
    for(j in strsplit(i,',')){
      genes_annotated_with_peaks<-c(genes_annotated_with_peaks,j)
    }
  }
  genes_annotated_with_peaks<-unique(genes_annotated_with_peaks)
  return(genes_annotated_with_peaks)
}


#create color map for TR activity visualization
color_map<-function(xs,n_bins=10,cmap='RdYlBu'){
  vmin<-min(xs)
  vmax<-max(xs)
  values<-seq(vmin,vmax,(vmax-vmin)/n_bins)
  palette<-rev(brewer.pal(n_bins,cmap))
  color_map_df<-list()
  color_map_df[['color']]<-palette
  color_map_df[['value1']]<-values[1:n_bins]
  color_map_df[['value2']]<-values[2:(n_bins+1)]
  color_map_df<-as.data.frame(color_map_df)
  return(as.character(lapply(xs,function(x){if(x>=vmax){return(palette[length(palette)])}else if(x<=vmin){
    return(palette[1])}else{return(as.character(color_map_df$color[c(color_map_df$value1<=x)&c(color_map_df$value2>x)]))}})))
}


