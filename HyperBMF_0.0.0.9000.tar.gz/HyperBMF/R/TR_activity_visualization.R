#' TR Activity visualization
#'
#' @param pcs     PCA analysis result from function Hypervariable_analysis.
#'
#' @param xs      The TR activities of TF motif/ER, stored in the result from function jointly_inferring_TR_activity_and_regulatory_network.
#'
#' @param motif   The name of TF motif/ER.
#'
#' @return null
#'
#' @export
#'
#' @author Haojie Chen
#'
#' @examples
#' #Hyper_ChIP_res from function Hypervariable_analysis. Details see "?Hypervariable_analysis".
#' #HyperBMF_res from function jointly_inferring_TR_activity_and_regulatory_network
#' #Details see "?jointly_inferring_TR_activity_and_regulatory_network".
#'
#' TF<-'HNF1A'
#' TF_activity_score_scatter_plot(HyperChIP_res$PCA,HyperBMF_res$TR_activity[TF,],TF)
#'
TR_activity_score_scatter_plot<-function(pcs,xs,motif){
  colors<-color_map(xs)
  plot(scores(pcs)[,'PC1'],scores(pcs)[,'PC2'],
       bg=colors,
       col='black',pch=21,
       xlab=gettextf('PC 1 (%.1f%%)',pcs@R2[1]*100),
       ylab=gettextf('PC 2 (%.1f%%)',pcs@R2[2]*100),
       main=motif,
       cex.lab=1.5,cex=2,cex.axis=1.5,cex.main=1.8)

  legend('topright',rev(c('Low','','Medium','','High')),
         inset=c(-0.42,0),
         pch=c(15),
         cex=1.5,
         col=rev(color_map(c(0,0.25,0.5,0.75,1))),ncol=1,
         xpd=T)

}
