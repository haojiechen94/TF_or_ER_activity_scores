#' @title Identify mutations associated with regulon activity through cis- or trans-effects
#'
#' @description
#' To identify mutations associated with regulon activity (RA) through cis- or trans-effects,
#' we fitted a multivariable linear regression model using the lm function in R,
#' with logit-transformed regulon activity as the response variable.
#' Mutation status was included as the primary predictor, while sex, age, body mass index (BMI),
#' and tumor mutational burden (TMB) were included as covariates:
#' logit(RA)~β_0+β_mutation⋅Muation+β_sex⋅Sex+β_age⋅Age+β_BMI⋅ BMI+β_TMB⋅ TMB+ε
#'
#'
#' @param mutation_matrix Mutation profile matrix, with genes in rows and samples in columns.
#' @param RA_matrix Regulon activity matrix, with transcriptional regulators in rows and samples in columns.
#' @param metadata Sample metadata, with samples in rows and metadata variables in columns.
#' @param covariates Character vector specifying the columns in metadata to be included as covariates in the multivariable linear regression model.
#' @param recurrent_gene_cutoff Minimum proportion of samples carrying a mutation in a gene for that gene to be considered recurrently mutated and included in downstream analyses. Must be between 0 and 1. Default: 0.02.
#' @return A list containing the results of cis- and trans-effect analyses.
#'
#' @author
#' Haojie Chen
#'
#' @examples
#' res_df<-Mutation_affect_regulon('./CCRCC_mutations.txt','./CCRCC_TR_activity.txt','./CCRCC_meta.txt',
#'            covariates=c('Age','Sex','BMI','TMB'),recurrent_gene_cutoff=0.05)
#'
#' @export
Mutation_affect_regulon<-function(mutation_matrix,
                                  RA_matrix,
                                  metadata,
                                  covariates=c(),recurrent_gene_cutoff=0.02){
  mutation_df<-read.table(mutation_matrix,
                          sep='\t',header=T,row.names=1,stringsAsFactors = F, check.names = F)
  Regulon_activity_df<-read.table(RA_matrix,
                                  sep='\t',header=T,row.names=1,stringsAsFactors = F, check.names = F)
  metadata_df<-read.table(metadata,sep='\t',header=T,row.names=1,stringsAsFactors = F, check.names = F)

  #select common samples
  common_samples<-colnames(Regulon_activity_df)[colnames(Regulon_activity_df) %in% colnames(mutation_df)]
  common_samples<-common_samples[common_samples %in% rownames(metadata_df)]
  common_samples
  print('Number of common samples:')
  print(length(common_samples))


  #select confident mutated genes
  genes<-rownames(mutation_df[rowMeans(mutation_df[,common_samples])>recurrent_gene_cutoff,])
  print('Number of recurrently mutated genes:')
  print(sum(rowMeans(mutation_df[,common_samples])>recurrent_gene_cutoff))
  print('Cutoff:')
  print(recurrent_gene_cutoff)

  print('cis-effect...')
  #cis-effect
  #transcriptional regulator mutaions
  TRs<-genes[genes %in% rownames(Regulon_activity_df)]

  betas<-c()
  pvals<-c()
  for(TR in TRs){

    y <- unlist(Regulon_activity_df[TR,common_samples])
    eps <- 1e-4
    y_adj <- pmin(pmax(y, eps),1 - eps)
    y_logit <- qlogis(y_adj)

    input_df<-metadata_df[common_samples,covariates,drop=F]
    input_df$mutation<-unlist(mutation_df[TR,common_samples])
    input_df$TRA<-y_logit

    if('Sex' %in% colnames(input_df)){
      input_df$Sex <- ifelse(
        input_df$Sex == "Female", 0,
        ifelse(input_df$Sex == "Male", 1, NA)
      )
    }


    input_df[] <- lapply(input_df, function(x) as.numeric(as.character(x)))


    model_df <- input_df[
      complete.cases(input_df[, colnames(input_df)]),
    ]

    model_formula <- reformulate(
      termlabels = colnames(model_df)[colnames(model_df)!='TRA'],
      response = "TRA"
    )


    fit <- lm(
      formula = model_formula,
      data = model_df
    )


    betas<-c(betas,summary(fit)$coefficients['mutation','Estimate'])
    pvals<-c(pvals,summary(fit)$coefficients['mutation','Pr(>|t|)'])

  }

  cis_effect_df<-data.frame('TR'=TRs,'beta'=betas,'pval'=pvals)
  cis_effect_df$padj<-p.adjust(cis_effect_df$pval,method='BH')

  #trans-effect
  print("trans-effect...")



  future::plan(
    future::multisession,
    workers = 10
  )

  base_df <- metadata_df[
    common_samples,
    covariates,
    drop = FALSE
  ]

  if ("Sex" %in% colnames(base_df)) {
    base_df$Sex <- ifelse(
      base_df$Sex == "Female", 0,
      ifelse(base_df$Sex == "Male", 1, NA)
    )
  }

  base_df[] <- lapply(
    base_df,
    function(x) as.numeric(as.character(x))
  )

  RA_mat <- as.matrix(
    Regulon_activity_df[, common_samples]
  )

  storage.mode(RA_mat) <- "numeric"

  eps <- 1e-4
  RA_logit <- qlogis(
    pmin(pmax(RA_mat, eps), 1 - eps)
  )

  TRs_all <- rownames(RA_logit)

  model_formula <- reformulate(
    c(covariates, "mutation"),
    response = "TRA"
  )

  trans_list <- future.apply::future_lapply(
    genes,
    function(gene) {

      mutation_vector <- as.numeric(
        mutation_df[gene, common_samples]
      )

      gene_result <- lapply(
        TRs_all,
        function(TR) {

          input_df <- base_df
          input_df$mutation <- mutation_vector
          input_df$TRA <- RA_logit[TR, ]

          model_df <- input_df[
            complete.cases(input_df),
            ,
            drop = FALSE
          ]

          fit <- tryCatch(
            lm(model_formula, data = model_df),
            error = function(e) NULL
          )

          if (is.null(fit)) {
            return(NULL)
          }

          coef_df <- summary(fit)$coefficients

          if (!"mutation" %in% rownames(coef_df)) {
            return(NULL)
          }

          data.frame(
            Mutated_gene = gene,
            TR = TR,
            beta = coef_df["mutation", "Estimate"],
            pval = coef_df["mutation", "Pr(>|t|)"]
          )
        }
      )

      do.call(
        rbind,
        gene_result
      )
    },
    future.seed = FALSE
  )

  trans_effect_df <- do.call(
    rbind,
    trans_list
  )

  trans_effect_df$padj <- p.adjust(
    trans_effect_df$pval,
    method = "BH"
  )

  future::plan(
    future::sequential
  )

  return(list('cis'=cis_effect_df,'trans'=trans_effect_df))
}
