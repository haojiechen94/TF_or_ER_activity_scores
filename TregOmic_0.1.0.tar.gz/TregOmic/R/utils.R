#' Calculating single-end p-value
get_single_end_pvalue<-function(biocond){
  df<-attr(biocond,"df")
  p.value<-pf(biocond$fold.change,df[1],df[2],lower.tail=F)
  return(p.value)
}

#' Mean-variance curve and most variable peak regions visualization
plot_MVC_and_MVPs<-function(MVC_fitting,type,flag){
  smoothScatter(MVC_fitting[[1]]$sample.mean,log10(MVC_fitting[[1]]$sample.var),
                xlab=expression(paste('Observed mean ',log[2],'(read count)')),
                ylab=expression(paste(Log[10],'(observed variance)')),
                main=gettextf('%s regions',type),cex.main=2,cex.lab=1.2,cex.axis=1.2)
  xs<-seq(min(MVC_fitting[[1]]$sample.mean),max(MVC_fitting[[1]]$sample.mean),0.1)
  lines(xs,log10(MVC_fitting[[1]]$fit.info$predict(xs)),lwd=3,col='red')
  points(MVC_fitting[[1]]$sample.mean[flag],log10(MVC_fitting[[1]]$sample.var)[flag],col='red')
  legend("bottomleft",gettextf('Significant HVRs (n=%s)',sum(flag)),
         inset=0.0025,
         pch=c(21),
         cex=1.5,
         col='red',
         xpd=T)
}

#' Mean-dispersion curve and most variable genes visualization
plot_MDC_and_MVGs<-function(dds,means,dispers,dispers_ratios,top_HVGs,flag,max_val){
  smoothScatter(means[flag],log10(dispers)[flag],
                xlab='Mean',ylab='Dispersion',
                xlim=c(0,max_val))
  lines(log2(10**seq(-0,max_val,0.1)),log10(dds@dispersionFunction(10**seq(-0,max_val,0.1))),col='red',lwd=3)
  points(means[flag][rank(dispers_ratios)>(length(dispers_ratios)-top_HVGs)],
         log10(dispers)[flag][rank(dispers_ratios)>(length(dispers_ratios)-top_HVGs)],col='red')

  legend("bottomleft",gettextf('Significant HVGs (n=%s)',top_HVGs),
         inset=0.0025,
         pch=c(21),
         cex=1.5,
         col='red',
         xpd=T)
}


#' Applying Principal component analysis on most variable peak regions.
PCA_analysis<-function(zscore_matrix,color_by){
  color_by<-as.character(color_by)
  unique_labels<-unique(color_by)
  color_list<-scales::hue_pal()(length(unique_labels))
  names<-c()
  values<-c()
  for(i in c(1:length(unique_labels))){
    names<-c(names,unique_labels[i])
    values<-c(values,color_list[[i]])
  }
  color_map<-setNames(values,names)
  colors<-c()
  for(i in color_by){
    colors<-c(colors,color_map[[i]])
  }

  pcs<-pcaMethods::pca(zscore_matrix,nPcs=2)

  plot(pcaMethods::scores(pcs)[,'PC1'],
       pcaMethods::scores(pcs)[,'PC2'],
       bg=colors,
       col='black',pch=21,
       xlab=gettextf('PC 1 (%.1f%%)',pcs@R2[1]*100),
       ylab=gettextf('PC 2 (%.1f%%)',pcs@R2[2]*100),
       cex.lab=1.2,cex=2,cex.axis=1.2,cex.main=1.8)
  legend('topright',names,
         pch=c(19),
         cex=1.3,
         col=values,ncol=1,
         xpd=T)
  return(pcs)
}

#' Applying TSNE dimension reduction analysis on most variable peak regions.
TSNE_visualization<-function(zscore_matrix,top_number_of_PCs,perplexity,color_by){

  color_by<-as.character(color_by)
  unique_labels<-unique(color_by)
  color_list<-scales::hue_pal()(length(unique_labels))
  names<-c()
  values<-c()
  for(i in c(1:length(unique_labels))){
    names<-c(names,unique_labels[i])
    values<-c(values,color_list[[i]])
  }
  color_map<-setNames(values,names)
  colors<-c()
  for(i in color_by){
    colors<-c(colors,color_map[[i]])
  }

  set.seed(1234)
  tsne_out<-Rtsne::Rtsne(zscore_matrix,dims=2,perplexity=perplexity,initial_dims=top_number_of_PCs)

  plot(tsne_out$Y[,1],tsne_out$Y[,2],
       col='black',pch=21,bg=colors,
       cex=1.5,cex.main=1.5,
       xlab='t-SNE dimension 1',ylab='t-SNE dimension 2',cex.lab=1.2,cex.axis=1.2)

  legend('topright',names,
         pch=c(19),
         cex=1.3,
         col=values,ncol=1,
         xpd=T)
  return(tsne_out)
}


#' Performing iterative matrix decomposition for each transcriptional regulator
#' using Bayesian inference implemented in the rstan package.
run<-function(N,M,TR,X,Mask_matrix,match_pos,data,i,TF_activity_model_stan,iter,output_samples,tol_rel_obj){
  data_to_model <- list(N = N, M = M, TR = TR, X = X, P = Mask_matrix[,i,drop=F])
  print('Fitting model...')
  fit.vb <- rstan::vb(TF_activity_model_stan,
               data = data_to_model,
               algorithm = "meanfield",
               iter = iter,
               output_samples = output_samples,
               tol_rel_obj = tol_rel_obj)

  TR_activity <- apply(rstan::extract(fit.vb,"A")[[1]], c(2,3), mean)
  TR_activity<-t(TR_activity)
  colnames(TR_activity)<-colnames(data)
  rownames(TR_activity)<-colnames(match_pos)[i]

  weights <- apply(rstan::extract(fit.vb,"W")[[1]], c(2,3), mean)
  colnames(weights)<-colnames(match_pos)[i]

  return(list('TR_activity'=TR_activity,'weights'=weights,
              'prior_matrix'=match_pos[,i,drop=F]))
}

#' Getting overlapping genes with ATAC/Chip-seq peaks. The input file should be
#' generated from the Epigenetic Analysis Platform (EAP; https://www.biosino.org/epigenetics/).
#' This function filters out transcriptional regulators that do not have
#' associated peaks and are therefore less likely to be actively expressed.
#'
getting_peak_associated_genes<-function(peaks_annotation_file){
  peaks_to_genes_links<-read.table(peaks_annotation_file,sep='\t',header=T)

  positions<-paste(peaks_to_genes_links$chrom,
                   peaks_to_genes_links$start,
                   peaks_to_genes_links$end,sep = '_')

  genes<-lapply(peaks_to_genes_links$overlapping_genes, function(x){strsplit(x,',')[[1]]})
  names(genes)<-positions
  return(genes)
}


#' Visualize regulon activity across sample groups.
boxplot_RA<-function(TregOmic_res,TR,categorical_variable){
  df<-data.frame('RA'=as.vector(TregOmic_res$RA_and_RP[[TR]][['TR_activity']]),
                 'Group'=TregOmic_res$metadata[[categorical_variable]])

  pair_list <- combn(unique(df$Group), 2, simplify = FALSE)

  ggpubr::ggboxplot(df,x='Group',y='RA',color='Group',size =1.5)+
    ggpubr::stat_compare_means(method = "wilcox",comparisons = pair_list)+
    ggplot2::labs(title=TR)+ggplot2::theme_classic()+
    ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5),text = ggplot2::element_text(size = 15))

}


#' Transform TregOmic results from a list structure into matrices for downstream analyses.
transform_to_matrix<-function(TregOmic_res){
  RA_matrix<-TregOmic_res$RA_and_RP[[1]]$TR_activity
  RP_matrix<-TregOmic_res$RA_and_RP[[1]]$weights
  prior_matrix<-TregOmic_res$RA_and_RP[[1]]$prior_matrix

  for(i in c(2:length(TregOmic_res$RA_and_RP))){
    RA_matrix<-rbind(RA_matrix,TregOmic_res$RA_and_RP[[i]]$TR_activity)
    RP_matrix<-rbind(RP_matrix,TregOmic_res$RA_and_RP[[i]]$weights)
    prior_matrix<-rbind(prior_matrix,TregOmic_res$RA_and_RP[[i]]$prior_matrix)
  }
  return(list('Regulon_activity'=RA_matrix,
              'Rgulatory_potential'=RP_matrix,
              'Prior_information'=prior_matrix))
}

#' Calculating the Spearman's correlation coefficient between regulon activities and its phosphorylation levels across each site
Get_correlated_sites<-function(TR,phosphomics,RA_matrix){
  sites<-c()
  pvals<-c()
  sccs<-c()
  common_samples<-colnames(RA_matrix)[colnames(RA_matrix) %in% colnames(phosphomics)]
  for(i in rownames(phosphomics)[phosphomics$gene_name==TR]){
    if(sum(unlist(phosphomics[i,common_samples]),na.rm=T)>0){
      r<-cor.test(unlist(phosphomics[i,common_samples]),
                  unlist(RA_matrix[TR,common_samples]),method='spearman')
      if(!is.na(r$estimate)){
        sccs<-c(sccs,r$estimate)
        pvals<-c(pvals,r$p.value)
        sites<-c(sites,i)
      }
    }
  }
  fdrs<-p.adjust(pvals,method='BH')
  scc_df<-data.frame('site'=sites,'scc'=sccs,'pval'=pvals,'fdr'=fdrs)
  return(scc_df)

}


#' Visualize regulon activity across sample groups.
scatter_plot_Pro_vs_Phos<-function(TR,site,proteomics,phosphomics,RA_matrix){
  common_samples<-colnames(RA_matrix)
  common_samples<-common_samples[common_samples %in% colnames(proteomics)]
  common_samples<-common_samples[common_samples %in% colnames(phosphomics)]

  phos_df<-data.frame(list('Phos'=scale(unlist(phosphomics[site,common_samples])),
                      'TRA'=scale(unlist(RA_matrix[TR,common_samples])),
                      'Cancer_type'=rep(gettextf('%s:%s SCC=%.2f',TR,strsplit(site,'\\|')[[1]][4],
                                                 cor(unlist(phosphomics[site,common_samples]),
                                                     unlist(RA_matrix[TR,common_samples]),
                                                     method='spearman')),length(common_samples))))

  p2<-ggplot2::ggplot(phos_df, ggplot2::aes(x=Phos, y=scale(TRA), color=Cancer_type)) +ggplot2::geom_point(size=3, alpha=0.2)+
    ggplot2::geom_smooth(method = "lm", se = FALSE, linewidth=1.2,fullrange=T)+ggplot2::xlim(-4,4)+ggplot2::ylim(-4,4)+
    ggplot2::theme_classic(base_size = 15)+
    ggplot2::xlab('Protein phosphorylation')+ggplot2::ylab('Transcription regulator activity')

  pro_df<-data.frame(list('Pro'=scale(unlist(proteomics[TR,common_samples])),
                  'TRA'=scale(unlist(RA_matrix[TR,common_samples])),
                  'Cancer_type'=rep(gettextf('%s SCC=%.2f',TR,
                                             cor(unlist(proteomics[TR,common_samples]),
                                                 unlist(RA_matrix[TR,common_samples]),
                                                 method='spearman')),length(common_samples))))

  p1<-ggplot2::ggplot(pro_df, ggplot2::aes(x=Pro, y=scale(TRA), color=Cancer_type)) +ggplot2::geom_point(size=3, alpha=0.2)+
    ggplot2::geom_smooth(method = "lm", se = FALSE, linewidth=1.2,fullrange=T)+ggplot2::xlim(-4,4)+ggplot2::ylim(-4,4)+
    ggplot2::theme_classic(base_size = 15)+
    ggplot2::xlab('Protein expression')+ggplot2::ylab('Transcription regulator activity')

  patchwork::wrap_plots(p1+p2)

}

#' Download curated CPTAC multi-omics dataset for TregOmic downstream analyses
download_data <- function(url, dest_file) {

  methods <- c("libcurl", "wget", "curl")

  for (m in methods) {

    try({
      download.file(
        url,
        dest_file,
        mode = "wb",
        method = m,
        quiet = TRUE
      )

      if (file.exists(dest_file))
        return(dest_file)

    }, silent = TRUE)
  }

  stop("Download failed. Please check internet connection.")
}


#' Visualize genes ranked by the number of transcriptional regulators
#' whose activities are significantly associated with mutations in each gene
hbar_plot<-function(trans_effect,pval_cutoff=0.001,topn=10,color='cyan'){

  a<-table(trans_effect$Mutated_gene[trans_effect$pval<pval_cutoff])
  a<-a[order(a)]
  d<-as.data.frame(a)
  d<-d[order(- d$Freq),]
  rownames(d)<-d$Var1
  d1<-d[1:topn,]
  d1$Var1<-factor(rownames(d1),levels = rev(rownames(d1)))
  d1$bar_alpha <- scales::rescale(d1$Freq, to = c(0.25, 1))

  ggplot2::ggplot(d1, ggplot2::aes(x = Var1, y = Freq,fill = I(color))) +
    ggplot2::geom_col(ggplot2::aes(alpha = bar_alpha), width = 0.7,color='black') +
    ggplot2::coord_flip()+  ggplot2::theme_classic()

}

#' Visualize regulon activity between mutated samples and wildtype samples.
boxplot_RA2<-function(mutation_matrix,RA_matrix,
                        TR,gene){
  mutation_df<-read.table(mutation_matrix,
                          sep='\t',header=T,row.names=1,stringsAsFactors = F, check.names = F)
  Regulon_activity_df<-read.table(RA_matrix,
                                  sep='\t',header=T,row.names=1,stringsAsFactors = F, check.names = F)


  #select common samples
  common_samples<-colnames(Regulon_activity_df)[colnames(Regulon_activity_df) %in% colnames(mutation_df)]

  df<-data.frame('mutation'=unlist(mutation_df[gene,common_samples]),
                 'TRA'=unlist(Regulon_activity_df[TR,common_samples]))
  ggpubr::ggboxplot(df,
            x = "mutation",
            y = "TRA",
            color = "mutation",
            add = "jitter") +
    ggpubr::stat_compare_means(method = "wilcox.test")+ggplot2::ggtitle(gettextf('TR:%s ~ Gene:%s',TR,gene))+
    ggplot2::scale_fill_manual(values = c('#0070b8','#d40d8c'))+
    ggplot2::scale_color_manual(values = c('#0070b8','#d40d8c'))+
    ggplot2::theme_classic()+
    ggplot2::theme(
      plot.title = ggplot2::element_text(hjust = 0.5),
      axis.text.x = ggplot2::element_text(
        angle = 0,
        hjust = 0.5,
        size = 12
      )
    )+ggplot2::scale_x_discrete(labels = c(
      "0" = "Wildtype",
      "1" = "Mutation"
    ))
}



