#' Calculating single-end p-value
get_single_end_pvalue<-function(biocond){
  df<-attr(biocond,"df")
  p.value<-pf(biocond$fold.change,df[1],df[2],lower.tail=F)
  return(p.value)
}

#' Mean-variance curve and most variable peak regions visualization
plot_MVC_and_MVPs<-function(MVC_fitting,type,flag){
  smoothScatter(MVC_fitting[[1]]$sample.mean,log10(MVC_fitting[[1]]$sample.var),
                xlab=expression(paste('Observed mean ',log[2],'(read count)')),
                ylab=expression(paste(Log[10],'(observed variance)')),
                main=gettextf('%s regions',type),cex.main=2,cex.lab=1.2,cex.axis=1.2)
  xs<-seq(min(MVC_fitting[[1]]$sample.mean),max(MVC_fitting[[1]]$sample.mean),0.1)
  lines(xs,log10(MVC_fitting[[1]]$fit.info$predict(xs)),lwd=3,col='red')
  points(MVC_fitting[[1]]$sample.mean[flag],log10(MVC_fitting[[1]]$sample.var)[flag],col='red')
  legend("bottomleft",gettextf('Significant HVRs (n=%s)',sum(flag)),
         inset=0.0025,
         pch=c(21),
         cex=1.5,
         col='red',
         xpd=T)
}

#' Mean-dispersion curve and most variable genes visualization
plot_MDC_and_MVGs<-function(dds,means,dispers,dispers_ratios,top_HVGs,flag,max_val){
  smoothScatter(means[flag],log10(dispers)[flag],
                xlab='Mean',ylab='Dispersion',
                xlim=c(0,max_val))
  lines(log2(10**seq(-0,max_val,0.1)),log10(dds@dispersionFunction(10**seq(-0,max_val,0.1))),col='red',lwd=3)
  points(means[flag][rank(dispers_ratios)>(length(dispers_ratios)-top_HVGs)],
         log10(dispers)[flag][rank(dispers_ratios)>(length(dispers_ratios)-top_HVGs)],col='red')

  legend("bottomleft",gettextf('Significant HVGs (n=%s)',top_HVGs),
         inset=0.0025,
         pch=c(21),
         cex=1.5,
         col='red',
         xpd=T)
}


#' Applying Principal component analysis on most variable peak regions.
PCA_analysis<-function(zscore_matrix,color_by){
  color_by<-as.character(color_by)
  unique_labels<-unique(color_by)
  color_list<-scales::hue_pal()(length(unique_labels))
  names<-c()
  values<-c()
  for(i in c(1:length(unique_labels))){
    names<-c(names,unique_labels[i])
    values<-c(values,color_list[[i]])
  }
  color_map<-setNames(values,names)
  colors<-c()
  for(i in color_by){
    colors<-c(colors,color_map[[i]])
  }

  pcs<-pcaMethods::pca(zscore_matrix,nPcs=2)

  plot(pcaMethods::scores(pcs)[,'PC1'],
       pcaMethods::scores(pcs)[,'PC2'],
       bg=colors,
       col='black',pch=21,
       xlab=gettextf('PC 1 (%.1f%%)',pcs@R2[1]*100),
       ylab=gettextf('PC 2 (%.1f%%)',pcs@R2[2]*100),
       cex.lab=1.2,cex=2,cex.axis=1.2,cex.main=1.8)
  legend('topright',names,
         pch=c(19),
         cex=1.3,
         col=values,ncol=1,
         xpd=T)
  return(pcs)
}

#' Applying TSNE dimension reduction analysis on most variable peak regions.
TSNE_visualization<-function(zscore_matrix,top_number_of_PCs,perplexity,color_by){

  color_by<-as.character(color_by)
  unique_labels<-unique(color_by)
  color_list<-scales::hue_pal()(length(unique_labels))
  names<-c()
  values<-c()
  for(i in c(1:length(unique_labels))){
    names<-c(names,unique_labels[i])
    values<-c(values,color_list[[i]])
  }
  color_map<-setNames(values,names)
  colors<-c()
  for(i in color_by){
    colors<-c(colors,color_map[[i]])
  }

  set.seed(1234)
  tsne_out<-Rtsne::Rtsne(zscore_matrix,dims=2,perplexity=perplexity,initial_dims=top_number_of_PCs)

  plot(tsne_out$Y[,1],tsne_out$Y[,2],
       col='black',pch=21,bg=colors,
       cex=1.5,cex.main=1.5,
       xlab='t-SNE dimension 1',ylab='t-SNE dimension 2',cex.lab=1.2,cex.axis=1.2)

  legend('topright',names,
         pch=c(19),
         cex=1.3,
         col=values,ncol=1,
         xpd=T)
  return(tsne_out)
}


#' Performing iterative matrix decomposition for each transcriptional regulator
#' using Bayesian inference implemented in the rstan package.
run<-function(N,M,TR,X,Mask_matrix,match_pos,data,i,TF_activity_model_stan,iter,output_samples,tol_rel_obj){
  data_to_model <- list(N = N, M = M, TR = TR, X = X, P = Mask_matrix[,i,drop=F])
  print('Fitting model...')
  fit.vb <- rstan::vb(TF_activity_model_stan,
               data = data_to_model,
               algorithm = "meanfield",
               iter = iter,
               output_samples = output_samples,
               tol_rel_obj = tol_rel_obj)

  TR_activity <- apply(rstan::extract(fit.vb,"A")[[1]], c(2,3), mean)
  TR_activity<-t(TR_activity)
  colnames(TR_activity)<-colnames(data)
  rownames(TR_activity)<-colnames(match_pos)[i]

  weights <- apply(rstan::extract(fit.vb,"W")[[1]], c(2,3), mean)
  colnames(weights)<-colnames(match_pos)[i]

  return(list('TR_activity'=TR_activity,'weights'=weights,
              'prior_matrix'=match_pos[,i,drop=F]))
}

#' Getting overlapping genes with ATAC/Chip-seq peaks. The input file should be
#' generated from the Epigenetic Analysis Platform (EAP; https://www.biosino.org/epigenetics/).
#' This function filters out transcriptional regulators that do not have
#' associated peaks and are therefore less likely to be actively expressed.
#'
getting_peak_associated_genes<-function(peaks_annotation_file){
  peaks_to_genes_links<-read.table(peaks_annotation_file,sep='\t',header=T)

  positions<-paste(peaks_to_genes_links$chrom,
                   peaks_to_genes_links$start,
                   peaks_to_genes_links$end,sep = '_')

  genes<-lapply(peaks_to_genes_links$overlapping_genes, function(x){strsplit(x,',')[[1]]})
  names(genes)<-positions
  return(genes)
}


# Visualize Regulon Activity Across Sample Groups.
boxplot_RA<-function(TregOmic_res,TR,categorical_variable){
  df<-data.frame('RA'=as.vector(TregOmic_res$RA_and_RP[[TR]][['TR_activity']]),
                 'Group'=TregOmic_res$metadata[[categorical_variable]])

  pair_list <- combn(unique(df$Group), 2, simplify = FALSE)

  ggpubr::ggboxplot(df,x='Group',y='RA',color='Group',size =1.5)+
    ggpubr::stat_compare_means(method = "wilcox",comparisons = pair_list)+
    ggplot2::labs(title=TR)+ggplot2::theme_classic()+
    ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5),text = ggplot2::element_text(size = 15))

}


# Transform TregOmic results from a list structure into matrices for downstream analyses.
transform_to_matrix<-function(TregOmic_res){
  RA_matrix<-TregOmic_res$RA_and_RP[[1]]$TR_activity
  RP_matrix<-TregOmic_res$RA_and_RP[[1]]$weights
  prior_matrix<-TregOmic_res$RA_and_RP[[1]]$prior_matrix

  for(i in c(2:length(TregOmic_ress$RA_and_RP))){
    TR_activity<-rbind(TR_activity,TregOmic_ress$RA_and_RP[[i]]$TR_activity)
    weights<-rbind(weights,TregOmic_ress$RA_and_RP[[i]]$weights)
    prior_matrix<-rbind(prior_matrix,TregOmic_ress$RA_and_RP[[i]]$prior_matrix)
  }
  return(list('Regulon_activity'=RA_matrix,
              'Rgulatory_potential'=RP_matrix,
              'Prior_information'=prior_matrix))
}


