#' @title Multi-layer regulation model for transcriptional regulator activity
#' @description
#' This function integrates somatic mutations, protein abundance, and
#' phosphosite abundance to characterize the multi-layer regulation of
#' transcriptional regulator activity. For each recurrently mutated
#' transcriptional regulator, an Elastic Net regression model is fitted
#' using logit-transformed regulon activity as the response variable and
#' protein abundance, recurrent mutations, and regulator-specific
#' phosphosites as predictors. Features with non-zero coefficients are
#' considered potential contributors to regulator activity.
#'
#' @param RA_path Path to the regulon activity matrix. Rows represent transcriptional regulators and columns represent samples.
#' @param proteomics_path Path to the protein abundance matrix. Rows represent proteins/genes and columns represent samples.
#' @param phosphomics_path Path to the phosphoproteomics matrix. Rows represent phosphosites and columns represent samples.
#' @param mutation_path Path to the somatic mutation matrix. Rows represent genes and columns represent samples. Mutation status should
#'   be encoded as binary values, with 1 indicating mutated and 0 indicating wild-type.
#' @param recurrent_gene_cutoff  Minimum fraction of samples carrying mutations in a gene for that gene to be considered recurrently mutated and
#'   included as a predictor in the model. Must range from 0 to 1. Default is 0.1.
#'
#' @returns A named list containing the Elastic Net regression results for each
#'   analyzed transcriptional regulator. Each element is a data frame containing
#'   the selected features and their regression coefficients, ordered by the
#'   absolute coefficient magnitude.
#' @export
#'
#' @examples
#' \dontrun{
#' res <- Multi_layer_regulation_model(
#'   RA_path = "regulon_activity.txt",
#'   proteomics_path = "proteomics.txt",
#'   phosphomics_path = "phosphomics.txt",
#'   mutation_path = "mutation.txt",
#'   recurrent_gene_cutoff = 0.1
#' )
#' }
Multi_layer_regulation_model<-function(RA_path,proteomics_path,phosphomics_path,mutation_path,
                                       recurrent_gene_cutoff=0.1){
  library(tidyverse)
  RA_matrix<-read.table(RA_path,header=T,sep='\t',row.names=1,stringsAsFactors = F,
                        check.names = F)
  proteomics<-read.table(proteomics_path,header=T,sep='\t',row.names=1,stringsAsFactors = F,
                         check.names = F)
  phosphomics<-read.table(phosphomics_path,header=T,sep='\t',row.names=1,stringsAsFactors = F,
                          check.names = F)
  mutations<-read.table(mutation_path,
                          sep='\t',header=T,row.names=1,stringsAsFactors = F, check.names = F)

  #select common samples
  common<-colnames(RA_matrix)[colnames(RA_matrix) %in% colnames(mutations)]
  common<-common[common %in% colnames(proteomics)]
  common<-common[common %in% colnames(phosphomics)]

  #filtering
  genes<-rownames(mutations[rowMeans(mutations[,common])>recurrent_gene_cutoff,])
  TRs<-rownames(mutations[rowMeans(mutations[,common])>recurrent_gene_cutoff,])
  TRs<-TRs[TRs %in% rownames(RA_matrix)]

  res_list<-list()
  for(TR in TRs){
    print(TR)
    df<-data.frame('PE'=unlist(proteomics[TR,common]),
                   'RA'=unlist(RA_matrix[TR,common]))
    df<-cbind(df,t(mutations[genes,common]))
    temp_df<-phosphomics[phosphomics$gene_name==TR,common]
    temp_df <- na.omit(temp_df)
    rownames(temp_df)<-unlist(lapply(rownames(temp_df), function(x){strsplit(x,'\\|')[[1]][4]}))
    df<-cbind(df,t(temp_df))


    y_col <- "RA"
    y <- df[[y_col]]
    eps <- 1e-4

    y_adj <- pmin(
      pmax(y, eps),
      1 - eps
    )
    y_logit <- qlogis(y_adj)


    x_df <- df %>%
      select(-all_of(y_col))

    set.seed(123)

    fit <- glmnet::cv.glmnet(
      x = as.matrix(x_df),
      y = y_logit,
      family = "gaussian",
      alpha = 0.5,
      nfolds = 10,
      standardize = TRUE
    )


    plot(fit)

    print('Best lambda')
    print(fit$lambda.min)


    coef_mat <- coef(fit, s = "lambda.min")

    coef_df <- data.frame(
      Feature = rownames(as.matrix(coef_mat)),
      Coefficient = as.numeric(as.matrix(coef_mat))
    ) %>%
      filter(Coefficient != 0) %>%
      arrange(desc(abs(Coefficient)))


    selected_features <- coef_df %>%
      filter(Feature != "(Intercept)")

    pred_logit <- predict(
      fit,
      newx = as.matrix(x_df),
      s = "lambda.min"
    )

    pred_activity <- plogis(pred_logit)

    performance <- tibble(
      Sample = rownames(df),
      Observed = y,
      Predicted = as.numeric(pred_activity)
    )

    R2 <- cor(
      performance$Observed,
      performance$Predicted,
      use = "complete.obs"
    )^2

    p1<-ggplot2::ggplot(performance, ggplot2::aes(x = Observed, y = Predicted)) +
      ggplot2::geom_point(size = 2, alpha = 0.8) +
      ggplot2::geom_smooth(method = "lm", se = FALSE, color = "black") +
      ggplot2::theme_bw(base_size = 14) +
      ggplot2::labs(
        title = paste0(TR,", Elastic Net model, R² = ", round(R2, 3)),
        x = "Observed TF activity",
        y = "Predicted TF activity"
      )
    top_n <- 20

    top_coef <- selected_features %>%
      slice_max(order_by = abs(Coefficient), n = top_n) %>%
      arrange(Coefficient)

    n_missing <- top_n - nrow(top_coef)

    if (n_missing > 0) {
      blank_df <- tibble(
        Feature = paste0("blank_", seq_len(n_missing)),
        Coefficient = 0,
        is_blank = TRUE
      )

      top_coef2 <- top_coef %>%
        mutate(is_blank = FALSE) %>%
        bind_rows(blank_df)
    } else {
      top_coef2 <- top_coef %>%
        mutate(is_blank = FALSE)
    }


    top_coef2$Feature <- factor(top_coef2$Feature, levels = c(blank_df$Feature,top_coef$Feature))
    p2<-ggplot2::ggplot(top_coef2,
                        ggplot2::aes(x = Feature,
                   y = Coefficient,
                   fill = Coefficient > 0)) +
      ggplot2::geom_col(width = 0.7) +
      ggplot2::coord_flip() +
      ggplot2::theme_classic(base_size = 15)+
      ggplot2::labs(
        x = NULL,
        y = "Coefficient",
        title = TR
      ) +
      ggplot2::theme(
        legend.position = "none"
      )+
      ggplot2::scale_fill_manual(values = c('#0092ca','#ff0000'))+
      ggplot2::scale_color_manual(values = c('#0092ca','#ff0000'))


    print(p1)
    print(p2)

    res_list[[TR]]<-coef_df


  }

  return(res_list)


}
