#' @title Identifying most variable genes (MVGs) using DESeq2
#'
#' @description
#' Applies most variable gene analysis to RNA-seq data from a group of samples
#' (n >= 3). MVGs are identified according to the ratio
#' between the observed gene-wise dispersion and the corresponding prior
#' dispersion estimated by DESeq2.
#'
#' @param input_count_table
#' Input count matrix containing gene expression data, where rows correspond
#' to genes and columns correspond to samples.
#'
#' @param metadata
#' A metadata table describing the samples included in the input count matrix.
#' For example, it may contain sample annotations such as tissue type, disease
#' status, or experimental condition.
#'
#' @param categorical_variable
#' A column name in the metadata table. Samples will be colored according to
#' this categorical variable in PCA and t-SNE visualizations.
#'
#' @param top_number_of_PCs
#' Number of principal components used as input for t-SNE dimensional reduction
#' (default: 2).
#'
#' @param perplexity
#' Perplexity parameter for t-SNE, which controls the effective number of
#' nearest neighbors considered when constructing the low-dimensional embedding
#' (default: floor((number_of_samples - 1) / 3)).
#'
#' @param gene_expressed_in_min_number_of_samples
#' Genes expressed in fewer than the specified number of samples will be
#' removed prior to analysis (default: 3).
#'
#' @param top_number_of_HVGs
#' Number of top-ranked genes selected as hypervariable genes (default: 2000).
#'
#' @returns
#' A list of dispersion ratios for each genes, gene expression matrix of HVGs and all genes,
#'          variance stabilization transform gene expression matrix of HVGs.
#'
#' @author Haojie Chen
#'
#' @return
#' A list containing:
#' \itemize{
#' \item Gene-wise dispersion ratios.
#' \item Expression matrix of all genes.
#' \item Expression matrix of identified hypervariable genes.
#' \item Variance-stabilized expression matrix of hypervariable genes.
#' \item PCA and t-SNE results for downstream visualization.
#' \item metadata.
#' }
#'
#' @author
#' Haojie Chen
#'
#' @examples
#' \dontrun{
#' DESeq2_res <- DESeq2_RNA_seq(
#' "./raw_read_counts.txt",
#' "./sample_info.txt",
#' "cancer_type",
#' top_number_of_PCs = 2,
#' perplexity = 0,
#' gene_expressed_in_min_number_of_samples = 3,
#' top_number_of_HVGs = 2000
#' )
#' }
#'
#' @export
#'
DESeq2_RNA_seq<-function(input_count_table,
                         metadata,
                         categorical_variable,
                         top_number_of_PCs=2,
                         perplexity=0,
                         gene_expressed_in_min_number_of_samples=3,
                         top_number_of_HVGs=1000){
  raw_reads_count<-read.table(input_count_table,header=T,sep='\t',row.names=1,stringsAsFactors = F,
                              check.names = F)
  meta_data<-read.table(metadata,sep=',',header=T,row.names=1,stringsAsFactors = F,
                        check.names = F)

  if(perplexity==0){
    perplexity<-floor((dim(meta_data)[1]-1)/3)
  }

  dds <- DESeq2::DESeqDataSetFromMatrix(countData = round(raw_reads_count),
                                colData = meta_data[,categorical_variable,drop=FALSE],
                                design = as.formula(paste('~',categorical_variable)))
  keep <- rowSums(DESeq2::counts(dds) >= 1) >= gene_expressed_in_min_number_of_samples
  dds <- dds[keep,]

  dds <- DESeq2::estimateSizeFactors(dds)
  normalized.counts<-DESeq2::counts(dds, normalized=TRUE)

  dds<-DESeq2::DESeq(dds)

  dispers<-DESeq2::dispersions(dds)
  flag<-log2(rowMeans(normalized.counts))>0
  dispers_ratios<-dispers[flag]/dds@dispersionFunction(rowMeans(normalized.counts)[flag])


  means<-log2(rowMeans(normalized.counts))

  max_val<-max(means)

  plot_MDC_and_MVGs(dds,means,dispers,dispers_ratios,top_number_of_HVGs,flag,max_val)

  zscore_matrix<-scale(t(log2(normalized.counts[flag,][rank(dispers_ratios)>(length(dispers_ratios)-top_number_of_HVGs),]+1)))

  color_by<-meta_data[[categorical_variable]]
  PCA_analysis(zscore_matrix,color_by)
  TSNE_visualization(zscore_matrix,top_number_of_PCs,perplexity,color_by)

  vsd <- DESeq2::vst(dds, blind=FALSE)

  return(list('dispers_ratios'=dispers_ratios,
              'HVGs'=log2(normalized.counts[flag,][rank(dispers_ratios)>(length(dispers_ratios)-top_number_of_HVGs),]+1),
              'log1p_norm_counts'=log2(normalized.counts+1),
              'vst'=SummarizedExperiment::assay(vsd),
              'metadata'=meta_data))


}



