#' @title Identify Most Variable Peak Regions (MVPs) Using HyperChIP
#'
#' @description
#' Applies HyperChIP-based variability analysis to ATAC-seq or ChIP-seq datasets
#' generated from a group of samples (n >= 3). The identified most variable peak
#' regions (MVPs) can subsequently be used to evaluate whether epigenomic
#' variation distinguishes biological or clinical sample groups.
#'
#' @param input_proximal,input_distal
#' Input files containing proximal and distal peak regions, respectively.
#' In each file, the first three columns specify the genomic coordinates of
#' peaks, whereas the remaining columns contain the read count matrix and the
#' occupancy matrix. Input files can be generated using the Epigenetic Analysis
#' Platform (EAP; https://www.biosino.org/epigenetics/) or by following the
#' tutorial available at https://github.com/haojiechen94/EAP.
#'
#' @param metadata
#' A metadata table describing the samples included in the input files.
#' For example, it may contain sample annotations such as tissue type,
#' disease status, or experimental condition.
#'
#' @param categorical_variable
#' A column name in the metadata table. Samples will be colored according to
#' this categorical variable in the PCA and t-SNE visualizations.
#'
#' @param top_number_of_PCs
#' Number of principal components used as input for t-SNE dimensional reduction
#' (default: 2).
#'
#' @param perplexity
#' Perplexity parameter for t-SNE, which controls the effective number of
#' nearest neighbors considered when constructing the low-dimensional embedding
#' (default: floor((number_of_samples - 1) / 3)).
#'
#' @param filtered_chromosomes
#' Chromosomes to exclude prior to analysis
#' (default: c("chrX", "chrY", "chrM")).
#'
#' @param fdr_cutoff
#' False discovery rate (FDR) threshold used to identify significant
#' hypervariable regions (HVRs) (default: 0.1).
#'
#' @return
#' A list containing HyperChIP results for both proximal and distal regions,
#' including identified MVPs, statistical significance measures, metadata and
#' downstream visualization results.
#'
#' @author
#' Haojie Chen
#'
#' @examples
#' #Data for this example are available in https://github.com/haojiechen94/TF_or_ER_activity_scores/tree/master/data
#' HyperChIP_res<-HyperChIP_ATAC_seq(
#' './proximal_peak_regions_2000bp.txt',
#' './distal_peak_regions_2000bp.txt',
#' './GAC_cellines_H3K27ac_ChIP_seq_metadata.csv',
#' categorical_variable='tissue_type',
#' top_number_of_PCs = 2,
#' perplexity = 0,
#' filtered_chromosomes = c("chrX", "chrY", "chrM"),
#' fdr_cutoff = 0.01
#' )
#' @export
#'
HyperChIP_ATAC_seq<-function(input_proximal,
                             input_distal,
                             metadata,
                             categorical_variable,
                             top_number_of_PCs=2,
                             perplexity=0,
                             filtered_chromosomes=c('chrX','chrY','chrM'),
                             fdr_cutoff=0.1){
  method<-'loc'
  proixmal_raw_reads_count<-read.table(input_proximal,header=T,sep='\t')
  proixmal_raw_reads_count<-proixmal_raw_reads_count[!c(proixmal_raw_reads_count$chrom %in% filtered_chromosomes),]
  distal_raw_reads_count<-read.table(input_distal,header=T,sep='\t')
  distal_raw_reads_count<-distal_raw_reads_count[!c(distal_raw_reads_count$chrom %in% filtered_chromosomes),]
  raw_reads_count<-rbind(proixmal_raw_reads_count,distal_raw_reads_count)
  num_of_samples<-0
  for(i in colnames(raw_reads_count)){
    if(grepl('.read_cnt',i)){
      num_of_samples<-num_of_samples+1
    }
  }
  if(perplexity==0){
    perplexity<-floor((num_of_samples-1)/3)
  }

  reads_count<-colnames(raw_reads_count)[c(4:(4+num_of_samples-1))]
  occupancy<-colnames(raw_reads_count)[c((4+num_of_samples):(4+num_of_samples+num_of_samples-1))]

  normalized_data<-MAnorm2::normalize(raw_reads_count,
                                      reads_count,occupancy,offset=0.5,baseline='pseudo-reference')
  normalized_data<-normalized_data[rowMeans(normalized_data[reads_count])>0.5,]
  biocond<-MAnorm2::bioCond(normalized_data[reads_count],
                   normalized_data[occupancy],name='chip_or_atac_seq')

  conds_list<-list(biocond)
  MVC_fitting<-MAnorm2::fitMeanVarCurve(conds_list,method=method,occupy.only=F,args.lp=list(nn=1.0))
  biocond<-MAnorm2::estParamHyperChIP(MVC_fitting[[1]])
  varTest<-MAnorm2::varTestBioCond(biocond)
  p_values<-get_single_end_pvalue(varTest)
  p_value<-p_values
  fdrs<-p.adjust(p_values,method='fdr')
  fdr<-fdrs
  result<-cbind(normalized_data[c('chrom','start','end')],
                normalized_data[reads_count],
                normalized_data[occupancy],
                varTest[,c('observed.mean','observed.var','prior.var','fold.change')],
                p_value,fdr)
  flag<-result$fdr<fdr_cutoff
  plot_MVC_and_MVPs(MVC_fitting,'Mean-variance curve',flag)

  zscore_matrix<-scale(t(result[result$fdr<fdr_cutoff,reads_count]))
  print('#HVRs')
  print(sum(result$fdr<fdr_cutoff))


  meta_data<-read.table(metadata,sep=',',header=T)
  color_by<-meta_data[[categorical_variable]]
  pcs<-PCA_analysis(zscore_matrix,color_by)
  tsne<-TSNE_visualization(zscore_matrix,top_number_of_PCs,perplexity,color_by)
  return(list('HVA'=result,
              'PCA'=pcs,'TSNE'=tsne,'metadata'=meta_data))

}
