#' @title Identify PTM Sites Associated with Regulon Activity
#'
#' @description
#' Identify post-translational modification (PTM) sites on transcriptional
#' regulators that are associated with changes in regulon activity by integrating
#' PTM-omics data with inferred regulon activities.
#'
#' Specifically, for each transcriptional regulator, two nested linear models
#' are fitted:
#'
#' \deqn{RA \sim PE}
#'
#' and
#'
#' \deqn{RA \sim PE + PTM_1 + PTM_2 + \cdots + PTM_n}
#'
#' where RA denotes regulon activity, PE denotes protein expression, and PTM
#' terms denote modification site abundances. An ANOVA is then performed to
#' compare the two models and identify PTM sites that explain additional
#' variation in regulon activity beyond protein abundance.
#'
#' @param RA_path Character string specifying the path to the regulon activity
#'   matrix. The matrix can be generated using \code{transform_to_matrix()}
#'   from the output of \code{TregOmic_RNA_seq()} or
#'   \code{TregOmic_ATAC_seq()}.
#'
#' @param proteomics_path Character string specifying the path to the protein
#'   expression matrix.
#'
#' @param phosphomics_path Character string specifying the path to the
#'   phosphoproteomics (or PTM-omics) matrix.
#'
#' @return
#' A list containing:
#' \itemize{
#'   \item \code{RA}: Regulon activity matrix.
#'   \item \code{PE}: Protein expression matrix.
#'   \item \code{PTM}: PTM abundance matrix.
#'   \item \code{PTM_associations}: Statistical results identifying PTM sites
#'   significantly associated with regulon activity after adjusting for
#'   protein abundance.
#' }
#'
#'
#' @examples
#' RA_path <- "./LUAD_TR_activity.txt"
#' proteomics_path <- "./LUAD_proteomics.txt"
#' phosphomics_path <- "./LUAD_phosphomics.txt"
#'
#' PTM_affect_regulon_res <- PTM_affect_regulon(
#'   RA_path,
#'   proteomics_path,
#'   phosphomics_path
#' )
#'
#' @export
PTM_affect_regulon<-function(RA_path,proteomics_path,phosphomics_path){
  RA_matrix<-read.table(RA_path,header=T,sep='\t',row.names=1,stringsAsFactors = F,
                        check.names = F)
  proteomics<-read.table(proteomics_path,header=T,sep='\t',row.names=1,stringsAsFactors = F,
                         check.names = F)
  phosphomics<-read.table(phosphomics_path,header=T,sep='\t',row.names=1,stringsAsFactors = F,
                         check.names = F)

  common_samples<-colnames(RA_matrix)
  common_samples<-common_samples[common_samples %in% colnames(proteomics)]
  common_samples<-common_samples[common_samples %in% colnames(phosphomics)]


  phosphomics$gene_name<-unlist(lapply(rownames(phosphomics), function(x){strsplit(x,'\\|')[[1]][1]}))

  selected_TRs<-rownames(RA_matrix)
  selected_TRs<-selected_TRs[selected_TRs %in% rownames(proteomics)]
  selected_TRs<-selected_TRs[selected_TRs %in% phosphomics$gene_name]


  pvals<-c()
  for(TR in selected_TRs){
    sites<-rownames(phosphomics[phosphomics$gene_name==TR,])
    temp<-rbind(proteomics[TR,common_samples],
                phosphomics[sites,common_samples],
                RA_matrix[TR,common_samples])
    rownames(temp)<-c('PE',unlist(lapply(1:length(sites), function(x)(gettextf('Phos%d',x)))),'TRA')
    temp<-as.data.frame(t(temp))
    formula_null<-as.formula('TRA ~ PE')
    formula_full<-as.formula(paste(colnames(temp)[length(colnames(temp))], "~", paste(colnames(temp)[1:(length(colnames(temp))-1)], collapse = " + ")))
    lm_null<-lm(formula_null,temp)
    lm_full<-lm(formula_full,temp)
    r<-anova(lm_null,lm_full)
    pvals<-c(pvals,r$`Pr(>F)`[[2]])
  }

  fdrs<-p.adjust(pvals,method='BH')
  phos_vs_pro_df<-data.frame('TR'=selected_TRs,'pval'=pvals,'fdr'=fdrs)

  phos_vs_pro_df<-phos_vs_pro_df[order(phos_vs_pro_df$pval,decreasing = F),,drop=F]

  return(list('phos_vs_pro'=phos_vs_pro_df,
              'RA'=RA_matrix,'Pro'=proteomics,'Phos'=phosphomics))
}



